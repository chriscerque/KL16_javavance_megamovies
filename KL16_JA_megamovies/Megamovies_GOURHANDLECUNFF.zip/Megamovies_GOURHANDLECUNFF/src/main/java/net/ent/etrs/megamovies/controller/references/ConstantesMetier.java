package net.ent.etrs.megamovies.controller.references;

public class ConstantesMetier {
    public static final String MSG_SUPPRESSION_IMPOSSIBLE = "Erreur lors de la suppression du film.";
    public static final String MSG_FILM_NON_SELECTIONNE = "Aucun film sélectionné.";
}
