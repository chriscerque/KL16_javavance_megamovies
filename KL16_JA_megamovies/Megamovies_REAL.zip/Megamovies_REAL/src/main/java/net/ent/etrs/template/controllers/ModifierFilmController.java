package net.ent.etrs.template.controllers;

import net.ent.etrs.template.model.entities.Film;

public class ModifierFilmController {


    public ModifierFilmController(Film f) {
    }


}
