package net.ent.etrs.template.model.entities.references;

public final class Constante {
    public static final int REALISATEUR_NOM_TAILLE_MAX = 50;
    public static final int TITRE__TAILLE_MAX = 50;
}
