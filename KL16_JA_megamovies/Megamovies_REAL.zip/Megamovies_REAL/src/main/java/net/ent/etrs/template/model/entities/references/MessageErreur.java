package net.ent.etrs.template.model.entities.references;

public final class MessageErreur {
    public static final String REALISATEUR_NOM_NULL = "Le réalisateur ne peut pas être null";
    public static final String REALISATEUR_NOM_TAILLE_MAX = "La taille max est de 50";
    public static final String TITRE__NULL = "Le titre ne peut pas etre null";
    public static final String TITRE__TAILLE_MAX = "La taille max est de 50";
    public static final String DATESORTIE__NULL = "Une date doit être renseigner";
    public static final String GENRE__NULL = "Un genre doit etre renseigner";
}
