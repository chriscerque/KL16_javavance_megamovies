package net.ent.etrs.template.view.references;

public final class Screens {

    public static final String SCREEN_ACCUEIL = "/screens/Accueil.fxml";
    public static final String SCREEN_APPLICATION_CSS = "";
    public static final String SCREEN_LISTER_FILM = "/screens/ListerFilm.fxml";
    public static final String SCREEN_CREER_FILM = "/screens/CreerFilm.fxml";
    public static final String MODIFIER_FILM = "/screens/ModifierFilm.fxml";
    public static final String VISIONNERFILM = "/screens/VisualiserFilm.fxml";
}
