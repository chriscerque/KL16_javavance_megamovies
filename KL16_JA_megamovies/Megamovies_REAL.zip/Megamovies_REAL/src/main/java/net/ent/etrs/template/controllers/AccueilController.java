package net.ent.etrs.template.controllers;

public class AccueilController {
}
