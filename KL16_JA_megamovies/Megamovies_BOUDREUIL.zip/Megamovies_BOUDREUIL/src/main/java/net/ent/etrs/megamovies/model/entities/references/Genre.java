package net.ent.etrs.megamovies.model.entities.references;

public enum Genre {
    THRILLER,
    COMEDIE,
    ACTION,
    SCIENCE_FICTION,
    MANGA;
}
