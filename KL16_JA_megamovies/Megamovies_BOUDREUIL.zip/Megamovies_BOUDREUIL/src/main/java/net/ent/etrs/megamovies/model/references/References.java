package net.ent.etrs.megamovies.model.references;

public class References {
    public static final String VOITURE_INIT = "/init/voiture.csv";
}
