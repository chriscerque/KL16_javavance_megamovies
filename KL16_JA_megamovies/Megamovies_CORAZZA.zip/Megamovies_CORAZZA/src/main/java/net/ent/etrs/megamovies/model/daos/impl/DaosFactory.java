package net.ent.etrs.megamovies.model.daos.impl;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DaosFactory {
//    public static AuteurDao fabriquerAuteurDao() {
//        return AuteurDaoImpl.getInstance();
//    }
}
