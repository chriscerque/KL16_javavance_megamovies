package net.ent.etrs.megamovies.model.facades;



public abstract class AbstractFacade<T> {

    //DaoClient daoClient = DaoFactory.fabriquerDaoClient();



}
