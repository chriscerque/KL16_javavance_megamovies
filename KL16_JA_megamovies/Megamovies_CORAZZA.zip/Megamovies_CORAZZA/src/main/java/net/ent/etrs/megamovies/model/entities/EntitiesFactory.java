package net.ent.etrs.megamovies.model.entities;


import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class EntitiesFactory<T extends AbstractEntity> {
//    public static Auteur fabriquerAuteur(String pseudo) throws ValidException {
//        return ValidatorUtils.validate(new Auteur(pseudo));
//    }
}
