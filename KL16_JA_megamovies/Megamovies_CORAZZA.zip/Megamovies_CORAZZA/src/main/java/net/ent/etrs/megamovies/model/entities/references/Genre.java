package net.ent.etrs.megamovies.model.entities.references;

public enum Genre {
    ACTION, SCIENCE_FICTION, COMEDIE, MANGA, THRILLER

}
