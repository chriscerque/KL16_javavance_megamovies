package net.ent.etrs.template.model.entities.references;

public enum Genre {

    ACTION,
    SCIENCE_FICTION,
    COMEDIE,
    MANGA,
    THRILLER;

    Genre() {
    }
}
