package net.ent.etrs.template.view.references;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class Screens {
    public static final String ACCUEIL = "/screens/Accueil.fxml";
    public static final String SCREEN_APPLICATION_CSS = "";
}
