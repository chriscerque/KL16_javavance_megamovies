package net.ent.etrs.template.model.controllers;

public class AcceuilController {
}
