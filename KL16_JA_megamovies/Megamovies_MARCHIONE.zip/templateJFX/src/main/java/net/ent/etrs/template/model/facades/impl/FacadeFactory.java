package net.ent.etrs.template.model.facades.impl;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class FacadeFactory {
//    public static FacadeRecette fabriquerFacadeRecette() {
//        return new FacadeRecetteImpl();
//    }
}
