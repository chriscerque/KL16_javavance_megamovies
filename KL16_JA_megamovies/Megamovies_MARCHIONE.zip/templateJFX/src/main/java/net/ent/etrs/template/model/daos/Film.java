package net.ent.etrs.template.model.daos;

public interface Film extends BaseDao<net.ent.etrs.template.model.entities.Film, Long> {
}
