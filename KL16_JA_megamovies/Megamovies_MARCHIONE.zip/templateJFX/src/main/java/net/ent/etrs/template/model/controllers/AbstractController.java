package net.ent.etrs.template.model.controllers;


public abstract class AbstractController {

}
