package net.ent.etrs.megamovie.model.entities.references;

public enum Genre {
    ACTION,
    SCIENCE_FICTION,
    COMEDIE,
    MANGA,
    THRILLER
}
