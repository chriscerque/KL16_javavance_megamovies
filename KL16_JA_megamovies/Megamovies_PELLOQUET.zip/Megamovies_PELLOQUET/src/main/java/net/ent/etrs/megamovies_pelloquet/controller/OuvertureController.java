package net.ent.etrs.megamovies_pelloquet.controller;

public class OuvertureController extends AbstractController{
    public static void init() {

    }
}
