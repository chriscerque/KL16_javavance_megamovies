package net.ent.etrs.megamovies_pelloquet.view.utils;


public final class Screens {
    public static final String SCREEN_ACCUEIL = "/screens/Ouverture.fxml";
    public static final String SCREEN_AJOUTER_FILM = "/screens/AjouterFilm.fxml";
    public static final String SCREEN_LISTER_FILMS = "/screens/ListerFilms.fxml";
    public static final String SCREEN_APPLICATION_CSS = "";

    private Screens() {
    }
}
