package net.ent.etrs.megamovies_pelloquet.start.references;

public class ConstantesLanceur {
    public static final String TITRE = "MegaMovies";
}
