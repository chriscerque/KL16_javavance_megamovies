package net.ent.etrs.megamovies_pelloquet.controller.references;

public class ConstantesController {

    public static final String ERREUR_INIT = "Problème dans la création de la Liste Observable.";
    public static final String ERREUR_CREATION = "Impossible de créer le film";
}
