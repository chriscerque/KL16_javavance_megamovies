package net.ent.etrs.megamovies.controllers;

public class AideController extends AbstractController {


}
