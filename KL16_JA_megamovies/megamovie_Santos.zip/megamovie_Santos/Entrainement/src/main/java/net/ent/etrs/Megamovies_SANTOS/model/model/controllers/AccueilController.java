package net.ent.etrs.Megamovies_SANTOS.model.model.controllers;

import javafx.event.ActionEvent;

public class AccueilController {

    public void creer(ActionEvent actionEvent) {
    }
}
