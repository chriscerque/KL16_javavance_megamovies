package net.ent.etrs.Megamovies_SANTOS.model.model.entities;

public enum Genre {
    ACTION,
    SCIENCE_FICTION,
    COMEDIE,
    MANGA,
    THILLER
}
