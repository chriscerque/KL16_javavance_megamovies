package net.ent.etrs.tmplatejvsfx.view;

public class ConstantesView {

    public static final String MSG_FILM_NON_SELECTIONNE = "Erreur";
}
