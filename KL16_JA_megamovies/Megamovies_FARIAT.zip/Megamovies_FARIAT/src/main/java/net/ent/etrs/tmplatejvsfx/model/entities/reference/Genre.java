package net.ent.etrs.tmplatejvsfx.model.entities.reference;

public enum Genre {
    ACTION,
    SCIENCE_FICTION,
    COMEDIE,
    MANGA,
    THRILLER
}
