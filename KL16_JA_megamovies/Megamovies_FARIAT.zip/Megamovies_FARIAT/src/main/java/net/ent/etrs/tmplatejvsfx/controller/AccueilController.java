package net.ent.etrs.tmplatejvsfx.controller;

public class AccueilController extends AbstractController{
}
