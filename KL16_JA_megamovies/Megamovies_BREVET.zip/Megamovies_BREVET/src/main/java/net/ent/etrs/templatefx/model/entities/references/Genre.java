package net.ent.etrs.templatefx.model.entities.references;

public enum Genre {
    ACTION,
    SCIENCE_FICTION,
    COMEDIE,
    MANGA,
    THRILLER
}
