package net.ent.etrs.templatefx.controller;

public class AccueilController extends AbstractController {
}
