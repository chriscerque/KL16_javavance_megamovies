package net.ent.etrs.templatefx.view.references;

public class ConstantesView {

    public static final String CONFIRMATION_DIALOG = "Quitter";
    public static final String CONFIRMATION = "Are you sure ???";
    public static final String CONFIRMATION_QUITTER = "Voulez-vous vraiment quitter l'application ???";
    public static final String LABEL_FILMO_BASE = "Film de : ";
}
