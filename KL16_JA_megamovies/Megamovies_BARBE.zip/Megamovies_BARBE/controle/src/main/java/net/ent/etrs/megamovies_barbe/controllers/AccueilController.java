package net.ent.etrs.megamovies_barbe.controllers;

public class AccueilController extends AbstractController {


}
