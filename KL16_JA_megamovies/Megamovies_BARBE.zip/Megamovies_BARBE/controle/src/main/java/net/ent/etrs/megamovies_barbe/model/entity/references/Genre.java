package net.ent.etrs.megamovies_barbe.model.entity.references;

public enum Genre {

    // ATTRIBUTES
    ACTION,
    SCIENCE_FICTION,
    COMEDIE,
    MANGA,
    THRILLER


}
