package net.ent.etrs.megamovies.model.daos.exceptions.references;

public class ConstantesDaoException {
    public static final String DAO_OBJECT_NULL = "";//TODO
    public static final String DAO_OBJECT_NOT_EXIST = "";//TODO
}
