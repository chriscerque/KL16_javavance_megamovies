package net.ent.etrs.megamovies.model.entities.references;

public final class ConstantesEntities {

    public static final int REALISATEUR_NOM_TAILLE_MAX = 50;
    public static final int FILM_TITRE_TAILLE_MAX = 50;
}

