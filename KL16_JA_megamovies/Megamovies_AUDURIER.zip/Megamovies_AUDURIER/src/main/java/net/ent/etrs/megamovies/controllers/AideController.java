package net.ent.etrs.megamovies.controllers;

/*
    Project Name : TpGarage
    File created by : adrien.audurier
    Date of creation : 20/01/2023
*/

public class AideController extends AbstractController {

}
