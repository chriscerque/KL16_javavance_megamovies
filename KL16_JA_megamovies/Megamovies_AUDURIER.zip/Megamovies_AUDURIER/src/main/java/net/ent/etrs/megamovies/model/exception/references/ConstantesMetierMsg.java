package net.ent.etrs.megamovies.model.exception.references;


public class ConstantesMetierMsg {

    public static final String REALISATEUR_NOM_NULL = "";
    public static final String REALISATEUR_NOM_TAILLE_MAX = "";
    public static final String REALISATEUR_GENRE_AJOUT = "";
    public static final String REALISATEUR_GENRE_SUPPR = "";
    public static final String FILM_TITRE_NULL = "";
    public static final String FILM_TITRE_TAILLE_MAX = "";
    public static final String FILM_GENRE_NULL = "";
    public static final String FILM_DATE_SORTIE_NULL = "";
    public static final String FILM_DATE_SORTIE_FUTURE = "";
    public static final String FILM_REALISATEUR_NULL = "";
    public static final String FILM_REALISATEUR_GENRE_IMPOSSIBLE = "";
}
