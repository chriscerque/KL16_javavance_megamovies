package net.ent.etrs.megamovies_falgat.controller;

public class AccueilController extends AbstractController{
}
