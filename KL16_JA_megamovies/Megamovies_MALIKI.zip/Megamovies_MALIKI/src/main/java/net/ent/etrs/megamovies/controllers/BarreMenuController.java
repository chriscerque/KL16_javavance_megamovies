package net.ent.etrs.megamovies.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.layout.VBox;

public class BarreMenuController extends AbstractController {
	
	@FXML
	public VBox barre;
	
	
	public void listerFilms(ActionEvent actionEvent) {
	
	}
	
	public void ajouterFilms(ActionEvent actionEvent) {
	
	}
	
	public void quitter(ActionEvent actionEvent) {
	
	}
	
	public void aide(ActionEvent actionEvent) {
	
	}
}
