package net.ent.etrs.megamovie.controller.references;

public class ConstantesView {
    public static final String CONFIRMATION_DIALOG = "";
    public static final String CONFIRMATION = "";
    public static final String CONFIRMATION_QUITTER = "";
}
