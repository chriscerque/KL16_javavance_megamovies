package net.ent.etrs.megamovie.view;

public class Screens {
    public static final String Accueil = "/view/Accueil.fxml";
    public static final String Liste = "/view/Lister.fxml";
    public static final String SCREEN_APPLICATION_CSS = "";
    public static String Ajout = "/view/Ajout.fxml";
}
