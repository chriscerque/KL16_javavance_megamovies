package net.ent.etrs.megamovie.model.exceptions;

public class Constante {
    public static final int REALISATEUR_NOM_TAILLE_MAX = 50;
    public static final int FILM_TITRE_TAILLE_MAX = 150;
    public static final int GENRE_TAILLE_MAX = 50;
}
