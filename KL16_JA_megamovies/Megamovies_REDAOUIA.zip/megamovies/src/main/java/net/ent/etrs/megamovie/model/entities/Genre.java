package net.ent.etrs.megamovie.model.entities;

public enum Genre {
    ACTION,
    SCIENCE_FICTION,
    COMEDIE,
    MANGA,
    THRILLER;
}
