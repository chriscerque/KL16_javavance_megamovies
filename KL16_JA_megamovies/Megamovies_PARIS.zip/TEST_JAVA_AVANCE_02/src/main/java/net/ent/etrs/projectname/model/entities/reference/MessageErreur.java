package net.ent.etrs.projectname.model.entities.reference;

public final class MessageErreur {
    public static final String FILM_GENRE_NULL = "Le genre du réalisateur doit être renseigné.";
    public static final String REALISATEUR_FILM_NULL = "Le réalisateur du film doit être renseigné.";
}
