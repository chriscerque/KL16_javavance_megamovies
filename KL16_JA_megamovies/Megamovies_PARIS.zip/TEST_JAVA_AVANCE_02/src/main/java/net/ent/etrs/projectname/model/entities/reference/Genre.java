package net.ent.etrs.projectname.model.entities.reference;

public enum Genre {

    ACTION,
    SCIENCE_FICTION,
    COMEDIE,
    MANGA,
    THRILLER;
}
