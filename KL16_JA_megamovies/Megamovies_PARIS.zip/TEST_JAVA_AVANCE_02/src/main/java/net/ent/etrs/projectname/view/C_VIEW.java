package net.ent.etrs.projectname.view;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class C_VIEW {

    public static final String CONFIRMATION_DIALOG = null;
    public static final String CONFIRMATION = null;
    public static final String CONFIRMATION_QUITTER = null;

}
