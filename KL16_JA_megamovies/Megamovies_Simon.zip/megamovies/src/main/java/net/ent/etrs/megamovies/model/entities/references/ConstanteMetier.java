package net.ent.etrs.megamovies.model.entities.references;

public class ConstanteMetier {

    public static final String DATE_SORTIE_EXCEPTION ="La date doit être renseigné." ;
    public static final String TITRE_FILM_NULL = "Le film doit être renseigné.";
    public static final int TITRE_FILM_TAILLE_MAX = 20;
    public static final String TITRE_FILM_TAILLE_MAX_EXCEPTION ="Maximum 20." ;
    public static final String NOM_REALISATEUR_NULL = "Le nom doit être renseigné.";
    public static final int NOM_REALISATEUR_TAILLE_MAX = 20;
    public static final String NOM_REALISATEUR_TAILLE_MAX_EXCEPTION = "La taille maximum est de 20. ";
    public static final String GENRE_REALISATEUR_NULL = "le genre doit être renseigné.";
    public static final String MSG_GENRE_AJOUTER_NULL = "";
    public static final String REALISATEUR_FILM_NULL = "Le réalisateur doit être renseigné.";
    public static final String FILM_GENRE_EXCEPTION = "Le genre doit être renseigné.";
}
