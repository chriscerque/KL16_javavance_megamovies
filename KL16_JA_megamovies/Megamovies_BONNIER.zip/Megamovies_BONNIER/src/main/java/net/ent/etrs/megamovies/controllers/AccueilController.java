package net.ent.etrs.megamovies.controllers;


public class AccueilController extends AbstractController {

}
